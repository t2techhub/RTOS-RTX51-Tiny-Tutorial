#include <REGX52.H>
#include <RTX51TNY.H>					//Su dung thu vien RTX51 Tiny Real-Time
#define INIT 0								//Dinh nghia INIT = 0
#define DO   1								//Dinh nghia DO = 1
sbit LED_DO 	= P1^0;					//Dinh nghia chan LED_DO
sbit LED_XANH = P1^2;					//Dinh nghia chan LED_XANH
void USART(void) interrupt 4  //Ngat nhan USART
{
  if(RI)											//Flag nhan duoc ki tu
	{														
    RI=0;							        //Clear flag
		isr_send_signal(DO);      //Gui signal cho task DO
	}
}
//=========Ham Start up==========
void Startup(void) _task_ INIT
{		
 SCON=0x52;                   //USART che do 1
 TMOD=0x21;	  						    //Timer 1 mode 2
 TH1=TL1=-3;	                //baudrate 9600
 TR1=1;
 IE=0x90;	 								    //Ngat USART   
 os_create_task (DO);					//Tao Task_Led_Do	
 os_delete_task (INIT);				//Xoa Task hien tai (Task 0)
}
void Task_Led_Do(void) _task_ DO 
{
	unsigned char event;
	while(1)
	{ 
		event = os_wait(K_SIG | K_TMO, 250,0); //Cho signal hoac time 250 ticks 
		if(event == TMO_EVENT) LED_DO ^= 1;    //Dao trang thai Led Do khi time out K_TMO	
    if(event == SIG_EVENT) 		//Nhan SIG_EVENT
		{
			LED_XANH ^= 1;					//Dao trang thai Led Xanh	
//			os_reset_interval(250); //Reset lai interval K_IVL
		}
	}
}

  